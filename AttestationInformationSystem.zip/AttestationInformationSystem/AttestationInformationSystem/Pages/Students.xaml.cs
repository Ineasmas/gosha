﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AttestationInformationSystem.Entities;
namespace AttestationInformationSystem.Pages
{
    /// <summary>
    /// Логика взаимодействия для Students.xaml
    /// </summary>
    public partial class Students : Page
    { Employees employee = new Employees();
        public Students(Employees enteredEmployee)
        {
            InitializeComponent();
            var student = Entities.Entities.GetContext().Student.ToList();
            LViewStudent.ItemsSource = student;
            DataContext = this;
            employee = enteredEmployee;
            txtFullname.Text = employee.FirstName.ToString() + " " + employee.LastName.ToString();
            UpdateData();
        }

        private void txtSearch_SelectionChanged(object sender, RoutedEventArgs e)
        {
            UpdateData();
        }
        private void UpdateData()
        {
            var result = Entities.Entities.GetContext().Student.ToList();
            result = result.Where(p => p.LastName.ToLower().Contains(txtSearch.Text.Trim().ToLower())||p.FirstName.ToLower().Contains(txtSearch.Text.Trim().ToLower())).ToList();
            LViewStudent.ItemsSource = result;
           
            
        }

        private void btChange_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddStudent());
        }

        private void btDelete_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
