﻿using AttestationInformationSystem.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using AttestationInformationSystem.Entities;
namespace AttestationInformationSystem.Pages
{
    /// <summary>
    /// Логика взаимодействия для Authorization.xaml
    /// </summary>
    public partial class Authorization : Page
    {
        private int countUnsuccessful = 0;
        DispatcherTimer timer = new DispatcherTimer();
        public Authorization()
        {
            InitializeComponent();
            tbCaptcha.Visibility = Visibility.Collapsed;
            tblCaptcha.Visibility = Visibility.Collapsed;
        }



        private void btEnter_Click(object sender, RoutedEventArgs e)
        {
            string login = tbLogin.Text.Trim();
            string password = tbPassword.Password.Trim();
            Employees employee = new Employees();
            employee = Entities.Entities.GetContext().Employees.Where(p => p.Login == login && p.Password == password).FirstOrDefault();
            if (countUnsuccessful < 1)
            {
                if (employee != null)
                {

                    NavigationService.Navigate(new Students(employee));
                }
                else
                {
                    MessageBox.Show("Вы ввели неверно логин или пароль!");
                    countUnsuccessful += 1;
                    GenerateCaptcha();
                }
            }
            else
            {
                if (tblCaptcha.Text == tbCaptcha.Text)
                {
                    if (employee != null)
                    {
                        tbCaptcha.Text = "";
                        NavigationService.Navigate(new Students(employee));
                        countUnsuccessful = 0;
                    }
                }
                else
                {
                    MessageBox.Show("Капча решена неверно!\nПовторите попытку входа через 10 секунд.");
                    BlockEnter();
                    countUnsuccessful = 0;
                    tbCaptcha.Visibility = Visibility.Hidden;
                    tblCaptcha.Visibility = Visibility.Hidden;
                }
            }

        }
        private void GenerateCaptcha()
        {
            tbCaptcha.Visibility = Visibility.Visible;
            tblCaptcha.Visibility = Visibility.Visible;
            Random rand = new Random();
            int lenghtcap = 6;
            const string characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            string result = "";
            for (int i = 0; i < lenghtcap; i++)
            {
                result += characters[rand.Next(characters.Length)];
            }
            tblCaptcha.Text = result;

        }

        private void BlockEnter()
        {
            btEnter.IsEnabled = false;
            tbLogin.IsEnabled = false;
            tbPassword.IsEnabled = false;
            timer.Interval = TimeSpan.FromSeconds(10);
            timer.Tick += BlockButtons;
            timer.Start();
        }

        private void BlockButtons(object sender, EventArgs e)
        {
            btEnter.IsEnabled = true;
            tbLogin.IsEnabled = true;
            tbPassword.IsEnabled = true;
            timer.Stop();
        }


        private void chbPassword_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}

